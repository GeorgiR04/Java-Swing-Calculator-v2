import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Info implements ActionListener {
    JFrame infoFrame = new JFrame();
    JTextField textArea = new JTextField(" Information");
    JTextField TextAreaDesc = new JTextField();
    JTextField TextAreaDesc1 = new JTextField();
    JTextField TextAreaDesc2 = new JTextField();
    JButton back = new JButton("Back");
    JButton exit = new JButton("Exit");



    Info(){

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                CalculatorDomashno back = new CalculatorDomashno();
                infoFrame.setVisible(false);
            }
        });

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                infoFrame.dispose();
            }
        });



        Border border = BorderFactory.createLineBorder(Color.GRAY, 2);
        Border border1 = BorderFactory.createLineBorder(Color.GRAY, 2);

        infoFrame.add(textArea);
        textArea.setEditable(false);
        textArea.setBounds(80, 10, 139, 30);
        textArea.setFont(new Font("", Font.PLAIN, 22));
        textArea.setBorder(border);

        infoFrame.add(TextAreaDesc);
        infoFrame.add(TextAreaDesc1);
        infoFrame.add(TextAreaDesc2);


        TextAreaDesc.setBounds(9, 55, 200, 30);
        TextAreaDesc.setText(" Creator: Georgi Rosenov Minchev ");
        TextAreaDesc.setBorder(border1);
        TextAreaDesc.setEditable(false);

        TextAreaDesc1.setBounds(9, 90, 200, 30);
        TextAreaDesc1.setText(" Date Created: 2022-04-20");
        TextAreaDesc1.setBorder(border1);
        TextAreaDesc1.setEditable(false);

        TextAreaDesc2.setBounds(9, 125, 200, 30);
        TextAreaDesc2.setText(" All Rights Reserved 2022-2028");
        TextAreaDesc2.setBorder(border1);
        TextAreaDesc2.setEditable(false);




        infoFrame.add(back);
        back.setBounds(220, 55, 70, 30 );
        back.setBorder(border);
        back.setFont(new Font("", Font.PLAIN, 14));

        infoFrame.add(exit);
        exit.setBounds(220, 90, 70, 30 );
        exit.setBorder(border);
        exit.setFont(new Font("", Font.PLAIN, 14));




        Image icon = Toolkit.getDefaultToolkit().getImage("src/info.png");
        infoFrame.setIconImage(icon);
        infoFrame.setLocation(500, 200);
        infoFrame.setTitle("Information Window");
        infoFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        infoFrame.setSize(300, 200);
        infoFrame.setLayout(null);
        infoFrame.setVisible(true);


    }
    @Override
    public void actionPerformed(ActionEvent actionEvent) {

    }
}

