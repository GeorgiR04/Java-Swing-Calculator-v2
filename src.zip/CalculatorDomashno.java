import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;



public class CalculatorDomashno implements ActionListener {
    JTextField textField = new JTextField();


    JButton buttonDel = new JButton("Delete");
    JButton button1 = new JButton("1");
    JButton button2 = new JButton("2");
    JButton button3 = new JButton("3");
    JButton button4 = new JButton("4");
    JButton button5 = new JButton("5");
    JButton button6 = new JButton("6");
    JButton button7 = new JButton("7");
    JButton button8 = new JButton("8");
    JButton button9 = new JButton("9");
    JButton button0 = new JButton("0");

    JButton buttonDot = new JButton(".");
    JButton buttonEquals = new JButton("=");
    JButton buttonClear = new JButton("C");
    JButton buttonPlus = new JButton("+");
    JButton buttonMinus = new JButton("-");
    JButton buttonMultiplication = new JButton("*");
    JButton buttonDivision = new JButton("/");

    JButton buttonInfo = new JButton("Info");

    static double a = 0, b = 0, result = 0;
    static int operator = 0;


    public CalculatorDomashno() {
        JFrame frame = new JFrame();


        frame.add(buttonInfo);
        buttonInfo.setBounds(10, 230, 60, 20);
        buttonInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Info info = new Info();
                frame.setVisible(false);
            }
        });



        frame.add(textField);
        textField.setBounds(7, 10, 255, 30);
        Border border = BorderFactory.createLineBorder(Color.GRAY, 2);
        textField.setBorder(border);
        textField.setEditable(false);

        frame.add(buttonDel);
        buttonDel.setBounds(95, 220, 75, 30);
        buttonDel.addActionListener(this);
        buttonDel.setFont(new Font("", Font.PLAIN, 16));
        buttonDel.setBorder(border);

        frame.add(button1);
        button1.setBounds(10, 60, 50, 30);
        button1.addActionListener(this);
        button1.setFont(new Font("", Font.PLAIN, 16));
        button1.setBorder(border);

        frame.add(button2);
        button2.setBounds(75, 60, 50, 30);
        button2.addActionListener(this);
        button2.setFont(new Font("", Font.PLAIN, 16));
        button2.setBorder(border);

        frame.add(button3);
        button3.setBounds(140, 60, 50, 30);
        button3.addActionListener(this);
        button3.setFont(new Font("", Font.PLAIN, 16));
        button3.setBorder(border);


        frame.add(button4);
        button4.setBounds(10, 100, 50, 30);
        button4.addActionListener(this);
        button4.setFont(new Font("", Font.PLAIN, 16));
        button4.setBorder(border);

        frame.add(button5);
        button5.setBounds(75, 100, 50, 30);
        button5.addActionListener(this);
        button5.setFont(new Font("", Font.PLAIN, 16));
        button5.setBorder(border);

        frame.add(button6);
        button6.setBounds(140, 100, 50, 30);
        button6.addActionListener(this);
        button6.setFont(new Font("", Font.PLAIN, 16));
        button6.setBorder(border);

        frame.add(button7);
        button7.setBounds(10, 140, 50, 30);
        button7.addActionListener(this);
        button7.setFont(new Font("", Font.PLAIN, 16));
        button7.setBorder(border);

        frame.add(button8);
        button8.setBounds(75, 140, 50, 30);
        button8.addActionListener(this);
        button8.setFont(new Font("", Font.PLAIN, 16));
        button8.setBorder(border);

        frame.add(button9);
        button9.setBounds(140, 140, 50, 30);
        button9.addActionListener(this);
        button9.setFont(new Font("", Font.PLAIN, 16));
        button9.setBorder(border);

        frame.add(button0);
        button0.setBounds(75, 180, 50, 30);
        button0.addActionListener(this);
        button0.setFont(new Font("", Font.PLAIN, 16));
        button0.setBorder(border);

        frame.add(buttonDot);
        buttonDot.setBounds(10, 180, 50, 30);
        buttonDot.addActionListener(this);
        buttonDot.setFont(new Font("", Font.PLAIN, 16));
        buttonDot.setBorder(border);

        frame.add(buttonEquals);
        buttonEquals.setBounds(140, 180, 50, 30);
        buttonEquals.addActionListener(this);
        buttonEquals.setFont(new Font("", Font.PLAIN, 16));
        buttonEquals.setBorder(border);

        frame.add(buttonClear);
        buttonClear.setBounds(210, 60, 50, 25);
        buttonClear.addActionListener(this);
        buttonClear.setFont(new Font("", Font.PLAIN, 16));
        buttonClear.setBorder(border);

        frame.add(buttonPlus);
        buttonPlus.setBounds(210, 90, 50, 25);
        buttonPlus.addActionListener(this);
        buttonPlus.setFont(new Font("", Font.PLAIN, 16));
        buttonPlus.setBorder(border);

        frame.add(buttonMinus);
        buttonMinus.setBounds(210, 120, 50, 25);
        buttonMinus.addActionListener(this);
        buttonMinus.setFont(new Font("", Font.PLAIN, 16));
        buttonMinus.setBorder(border);

        frame.add(buttonMultiplication);
        buttonMultiplication.setBounds(210, 150, 50, 25);
        buttonMultiplication.addActionListener(this);
        buttonMultiplication.setFont(new Font("", Font.PLAIN, 16));
        buttonMultiplication.setBorder(border);

        frame.add(buttonDivision);
        buttonDivision.setBounds(210, 180, 50, 25);
        buttonDivision.addActionListener(this);
        buttonDivision.setFont(new Font("", Font.PLAIN, 16));
        buttonDivision.setBorder(border);


        LocalDate now = LocalDate.now();
        JTextArea date = new JTextArea();
        date.setText(String.valueOf(now));
        date.setBounds(190, 230, 69, 20);
        date.setBorder(border);

        frame.add(date);
        Image icon = Toolkit.getDefaultToolkit().getImage("/home/noname/IdeaProjects/Calculator/src/icon.png");
        frame.setIconImage(icon);
        frame.setLocation(500, 200);
        frame.setTitle("Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(270, 290);
        frame.setLayout(null);
        frame.setVisible(true);


    }


    @Override
    public void actionPerformed(ActionEvent e) {


        if (e.getSource() == button1)
            textField.setText(textField.getText().concat("1"));
        if (e.getSource() == button2)
            textField.setText(textField.getText().concat("2"));
        if (e.getSource() == button3)
            textField.setText(textField.getText().concat("3"));
        if (e.getSource() == button4)
            textField.setText(textField.getText().concat("4"));
        if (e.getSource() == button5)
            textField.setText(textField.getText().concat("5"));
        if (e.getSource() == button6)
            textField.setText(textField.getText().concat("6"));
        if (e.getSource() == button7)
            textField.setText(textField.getText().concat("7"));
        if (e.getSource() == button8)
            textField.setText(textField.getText().concat("8"));
        if (e.getSource() == button9)
            textField.setText(textField.getText().concat("9"));
        if (e.getSource() == button0)
            textField.setText(textField.getText().concat("0"));
        if (e.getSource() == buttonDot)
            textField.setText(textField.getText().concat("."));
        if (e.getSource() == buttonPlus) {
            a = Double.parseDouble(textField.getText());
            operator = 1;
            textField.setText("");
        }

        if (e.getSource() == buttonMinus) {
            a = Double.parseDouble(textField.getText());
            operator = 2;
            textField.setText("");
        }

        if (e.getSource() == buttonMultiplication) {
            a = Double.parseDouble(textField.getText());
            operator = 3;
            textField.setText("");
        }

        if (e.getSource() == buttonDivision) {
            a = Double.parseDouble(textField.getText());
            operator = 4;
            textField.setText("");
        }

        if (e.getSource() == buttonEquals) {
            b = Double.parseDouble(textField.getText());
            switch (operator) {
                case 1:
                    result = a + b;
                    break;
                case 2:
                    result = a - b;
                    break;
                case 3:
                    result = a * b;
                    break;
                case 4:
                    result = a / b;
                    break;
                default:
                    result = 0;
            }
            textField.setText("" + result);
        }

        if (e.getSource() == buttonClear)
            textField.setText("");

        if (e.getSource() == buttonDel) {
            String s = textField.getText();
            textField.setText("");
            for (int i = 0; i < s.length() - 1; i++)
                textField.setText(textField.getText() + s.charAt(i));
        }

    }

}









